package com.hoquochuy911.nhanviensql;

public class Enum {
    public enum Gender{
        Nam,
        Nữ
    }
}
