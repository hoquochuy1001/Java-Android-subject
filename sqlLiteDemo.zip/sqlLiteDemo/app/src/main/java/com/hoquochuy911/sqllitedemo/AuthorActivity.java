package com.hoquochuy911.sqllitedemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class AuthorActivity extends AppCompatActivity {
    EditText edt_id, edt_name, edt_address, edt_email;
    Button bt_save, bt_select, bt_exit, bt_update, bt_delete;
    GridView gv_display;
    DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_author);

        edt_id = findViewById(R.id.edt_id);
        edt_name = findViewById(R.id.edt_name);
        edt_address = findViewById(R.id.edt_address);
        edt_email = findViewById(R.id.edt_email);

        bt_save = findViewById(R.id.btn_save);
        bt_select = findViewById(R.id.btn_select);
        bt_exit = findViewById(R.id.button_exit);
        bt_delete = findViewById(R.id.btn_delete);

        gv_display = findViewById(R.id.gridview_display);

        bt_select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Author author = new Author();
                author.setId_author(Integer.parseInt(edt_id.getText().toString()));
                author.setName(edt_name.getText().toString());
                author.setAddress(edt_address.getText().toString());
                author.setEmail(edt_email.getText().toString());

                if(databaseHelper.insertAuthor(author) > 0)
                    Toast.makeText(AuthorActivity.this, "Done", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(AuthorActivity.this, "Nahh", Toast.LENGTH_SHORT).show();
            }
        });

        View select = findViewById(R.id.btn_select);

        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ArrayList<Author> list_author;
                ArrayList<String> list_string = new ArrayList<>();

                list_author = databaseHelper.getAllAuthor();

                for(Author author:list_author){
                    list_string.add(author.getId_author()+"");
                    list_string.add(author.getName());
                    list_string.add(author.getAddress());
                    list_string.add(author.getEmail());
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<>(AuthorActivity.this,
                        android.R.layout.simple_list_item_1, list_string);
                gv_display.setAdapter(adapter);
            }
        });

    }
}