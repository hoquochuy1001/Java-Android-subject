package com.hoquochuy911.tuan3_ui;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button bt_chon = findViewById(R.id.button_chon);
        bt_chon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(MainActivity.this,"Done", Toast.LENGTH_LONG).show();
                AlertDialog.Builder mydialog = new AlertDialog.Builder(MainActivity.this);
                mydialog.setTitle("Nofication");

                final CharSequence[] items = {"Red", "Yello", "Orange"};
                boolean[] arraycheck = {true, false, true};

                mydialog.setMultiChoiceItems(items, arraycheck, new DialogInterface.OnMultiChoiceClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        arraycheck[which] = isChecked;
                    }
                });
                mydialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        String st = "";
                        for(int i = 0; i<items.length; i++){
                            if(arraycheck[i]){
                                st += items[i].toString();
                            }
                        }
                        Toast.makeText(MainActivity.this, st, Toast.LENGTH_LONG).show();
                    }
                });

//                mydialog.setSingleChoiceItems(items, -1, new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        Toast.makeText(MainActivity.this, items[which].toString(), Toast.LENGTH_LONG).show();
//                    }
//                });

//                mydialog.setItems(items, new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        Toast.makeText(MainActivity.this, items[which].toString(), Toast.LENGTH_LONG).show();
//                    }
//                });

//                mydialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        Toast.makeText(MainActivity.this, "No done", Toast.LENGTH_LONG).show();
//                    }
//                });
//                mydialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialog, int which) {
//                        Toast.makeText(MainActivity.this, "Yes done", Toast.LENGTH_LONG).show();
//                    }
//                });
                AlertDialog alertDialog = mydialog.create();
                alertDialog.show();
            }
        });

    }
}